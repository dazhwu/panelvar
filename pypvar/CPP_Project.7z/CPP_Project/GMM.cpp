
#include "GMM.h"


#define EIGEN_INITIALIZE_MATRICES_BY_ZERO

std::vector<Step_Result> results;
int steps;
int num_dep_lags;
// std::tuple<vector<Step_Result> , Hansen_test_info , vector<AR_test_info>

returned_result::returned_result(struct Regression &reg,
                                 Hansen_test_info &_hansen,
                                 VectorXcd &_stability,
                                 struct basic_info &mo_info, struct model_options &_m_options,string com_str) {
  regression_result = reg;
  hansen = _hansen;
  stability = _stability;
  model_info = mo_info;
  model_options=_m_options;
  command_str = com_str;
}

returned_result
regular_process(Eigen::Ref<RowMatrixXd> z_list,
                std::unordered_map<string, RowMatrixXd> &final_xy_tables,
                struct basic_info &model_info, struct model_options &options) {

  Eigen::Ref<RowMatrixXd> Cx_list = final_xy_tables["Cx"];
  Eigen::Ref<RowMatrixXd> Cy_list = final_xy_tables["Cy"];

  // //saveData("cy.csv", Cy_list);

  // //saveData("z.csv", z_list);
  string transformation = options.transformation;
  steps = options.steps;
  bool level = options.level;
  int N = model_info.N;
  int T = model_info.T;
  num_dep_lags=model_info.num_dep_lags;
  // int num_instru = model_info.num_instr;
  // int num_indep = model_info.num_indep;
  int num_obs = model_info.num_obs;
  int diff_width = model_info.diff_width;

  RowMatrixXd _XZ, _Zy;

  MatrixXd _z_t_list = z_list.transpose();

  results.clear();
  //cout <<"----calculate basic" << endl;
  std::tie(_XZ, _Zy) = calculate_basic(z_list, Cx_list, Cy_list, N);

  RowMatrixXd _XZ_t = _XZ.transpose();
  RowMatrixXd _Zy_t = _Zy.transpose();
//cout <<"----GMM" << endl;
  GMM(N, T, num_obs, diff_width, z_list, _z_t_list, Cx_list, Cy_list, _XZ,
      _XZ_t, _Zy, _Zy_t, 1, transformation, level);

  if ((steps == 1) || (steps == 2)) {
    GMM(N, T, num_obs, diff_width, z_list, _z_t_list, Cx_list, Cy_list, _XZ,
        _XZ_t, _Zy, _Zy_t, 2, transformation, level);
    steps = 2;
  } else {
    iterative_GMM(N, T, num_obs, diff_width, z_list, _z_t_list, Cx_list,
                  Cy_list, _XZ, _XZ_t, _Zy, _Zy_t, transformation, level);
    // steps=options.steps;
  }
  int num_steps = results.size();
  // Ref<RowMatrixXd> _zs_list = results[num_steps - 1]._zs_list;

  Hansen_test_info hansen = perform_hansen_test(
      steps, model_info.num_instr, model_info.num_indep, model_info.num_dep, N);

  //cout <<" hansen finished" << endl;
  VectorXcd stability =
      stability_test(results[steps - 1].beta, model_info.num_dep_lags);
  // vector<AR_test_info> ar_list =
  // 	perform_AR_test(final_xy_tables, z_list, _zs_list, 2, diff_width, N,
  // 		transformation, level);
  //cout << "stability finished" << endl;
  Regression tbr =
      Regression(results[num_steps - 1].beta, results[num_steps - 1].vcov,
      results[num_steps - 1].std_err,
                 results[num_steps - 1].W, z_list, Cy_list, Cx_list, results[num_steps-1].residual
				 );  //_residual_t
  // return
  // std::make_tuple(results[steps-1].beta,results[steps-1].std_err,results[steps-1].vcov,results[steps-1].SS,
  // hansen, ar_list, z_list);
  //cout << " --" << endl;
  model_info.SS = results[num_steps - 1].SS;
  model_info.actual_steps = steps;
  update_MMSC_LU(model_info, hansen);
  //cout << "MMSC_LU " <<endl;
  returned_result the_result =
      returned_result(tbr, hansen, stability, model_info, options, "");

  return the_result;
  //     self.perform_test(model, 2)
  // else:
  //     self.iterative_GMM(model, _XZ, _XZ_t, _Zy, _Zy_t)
  //     self.perform_test(model, model.options.steps)
}

void update_MMSC_LU(struct basic_info &model_info, Hansen_test_info &hansen) {
  double log_n = log(model_info.num_obs);
  // double dif = (model_info.num_instr -
  // model_info.num_indep)*model_info.num_dep;
  double dif = model_info.num_instr * model_info.num_dep - model_info.num_indep;
  model_info.mmsc_lu.BIC = hansen.test_value - (dif)*log_n;
  model_info.mmsc_lu.HQIC = hansen.test_value - dif * log(log_n) * 2.1;
  model_info.mmsc_lu.AIC = hansen.test_value - (dif)*2.0;
  
}


void iterative_GMM(int N, int T, int num_obs, int diff_width,
                   Ref<RowMatrixXd> z_list, Ref<MatrixXd> z_list_t,
                   Ref<RowMatrixXd> Cx_list, Ref<RowMatrixXd> Cy_list,
                   Ref<RowMatrixXd> _XZ, Ref<RowMatrixXd> _XZ_t,
                   Ref<RowMatrixXd> _Zy, Ref<RowMatrixXd> _Zy_t,
                   string transformation, bool level) {
  int current_step = 1; //,
  // int previous_step;
  bool converged = false;
  while (!converged) {
    // int previous_step = current_step;
    current_step += 1;

    GMM(N, T, num_obs, diff_width, z_list, z_list_t, Cx_list, Cy_list, _XZ,
        _XZ_t, _Zy, _Zy_t, current_step, transformation, level);
    Ref<RowMatrixXd> beta_current = results[current_step - 1].beta;
    Ref<RowMatrixXd> beta_previous = results[current_step - 2].beta;
    double nom = 0, denom = 0;
    for (int j = 0; j < beta_current.rows(); ++j) {

      double temp = pow((beta_current(j, 0) - beta_previous(j, 0)), 2);
      double temp2 = pow(beta_previous(j, 0), 2);

      nom += temp;
      denom += temp2;
    }
    double crit = sqrt(nom / denom);

    if (crit < 0.000001) {
      converged = true;
      steps = current_step;
    }
  }
}

void GMM(int N, int T, int num_obs, int diff_width, Ref<RowMatrixXd> z_list,
         Ref<MatrixXd> z_list_t, Ref<RowMatrixXd> Cx_list,
         Ref<RowMatrixXd> Cy_list, Ref<RowMatrixXd> _XZ, Ref<RowMatrixXd> _XZ_t,
         Ref<RowMatrixXd> _Zy, Ref<RowMatrixXd> _Zy_t, int step,
         string transformation, bool level) {

  int y_width = Cy_list.cols();

  RowMatrixXd diag_dep = RowMatrixXd::Identity(y_width, y_width);
  RowMatrixXd W, temp_W;
  if (step == 1) {
    RowMatrixXd H1;
    H1 = get_H1(z_list, diff_width, T, transformation, level);
    
    temp_W = calculate_W(H1, z_list, z_list_t, 1, N);
    
    W = Eigen::kroneckerProduct(temp_W, diag_dep);

    

  } else {
    Step_Result previous_step = results[step - 2];
    W = previous_step.W_next;
    //		//saveData("W2.csv", W);
  }

  //cout << W << endl;
  RowMatrixXd W_inv = common_inv(W);
  RowMatrixXd _XZ_W = _XZ * W_inv;

  RowMatrixXd _M_inv = _XZ_W * _XZ_t;
  RowMatrixXd M = common_inv(_M_inv);

  RowMatrixXd _M_XZ_W = M * _XZ_W;

  RowMatrixXd beta =
      (_M_XZ_W * _Zy_t)
          .reshaped<Eigen::RowMajor>(Cx_list.cols(), Cy_list.cols());

cout << beta << endl;
  RowMatrixXd residual = calculate_residual(Cy_list, Cx_list, beta);

  RowMatrixXd _residual_t = residual.transpose();
  RowMatrixXd SS = (_residual_t * residual) * (1.0 / 2 / num_obs);

  RowMatrixXd qs, _zs_list, zs, ZuuZ;
  std::tie(qs, _zs_list, zs, ZuuZ)= calculate_ZuuZ(N, z_list, residual, diag_dep, y_width) ;
//  cout << ZuuZ << endl;
  RowMatrixXd W_next = ZuuZ * (1.0 / N);

  RowMatrixXd _vcov;

  if (step == 1)
    _vcov = vcov_step_1(_M_XZ_W, W_next, N);
  else
    _vcov = vcov(z_list, Cx_list, M, _M_XZ_W, W_inv, qs, step, N);

  //cout << _vcov << endl;
  RowMatrixXd std_err(Cx_list.cols(), Cy_list.cols()), temp;

  temp = _vcov.diagonal();

  for (int i = 0; i < Cx_list.cols(); ++i)
    for (int j=0; j< Cy_list.cols(); ++j)
      std_err(i, j) = sqrt(temp(i*Cy_list.cols()+j, 0));
  cout<<std_err<<endl;

  Step_Result current_step =
      Step_Result(W, W_inv, W_next, _XZ_W, M, zs, ZuuZ, _vcov, _M_XZ_W,
                  _zs_list, beta, std_err, residual, _residual_t, SS);

  results.push_back(current_step);
}

std::tuple<RowMatrixXd, RowMatrixXd, RowMatrixXd, RowMatrixXd>
calculate_ZuuZ(int N, Ref<RowMatrixXd> z_list, RowMatrixXd &residual, RowMatrixXd &diag_dep,
               int y_width) {

  int z_height = z_list.rows() / N;
  // int z_width = z_list.cols();
  int r_height = residual.rows() / N;

  int zs_height = z_height * y_width;
  RowMatrixXd _zs_list = RowMatrixXd::Zero(N * zs_height, 1);
  RowMatrixXd zs = RowMatrixXd::Zero(zs_height, 1);
  RowMatrixXd qs = RowMatrixXd::Zero(z_height, y_width);
  RowMatrixXd ZuuZ = RowMatrixXd::Zero(zs_height, zs_height);
#pragma omp parallel for reduction(+ : zs, qs, ZuuZ)
  for (int i = 0; i < N; ++i) {

    Map<RowMatrixXd> u(residual.middleRows(i * r_height, r_height).data(),
                       r_height * y_width, 1);

//    if(i==0)
//      cout <<z_list.middleRows(i * z_height, z_height) <<endl;

    qs.noalias() += z_list.middleRows(i * z_height, z_height) *
                    residual.middleRows(i * r_height, r_height);
    _zs_list.middleRows(i * zs_height, zs_height) =
        Eigen::kroneckerProduct(z_list.middleRows(i * z_height, z_height),               diag_dep) *        u;

    Ref<RowMatrixXd> temp_zs = _zs_list.middleRows(i * zs_height, zs_height);
    zs.noalias() += temp_zs;
    ZuuZ.noalias() += temp_zs * temp_zs.transpose();
  }
  return std::make_tuple(qs, _zs_list, zs, ZuuZ);
}

std::tuple<RowMatrixXd, RowMatrixXd> calculate_basic(Ref<RowMatrixXd> z_list,
                                                     Ref<RowMatrixXd> Cx_list,
                                                     Ref<RowMatrixXd> Cy_list,
                                                     int N) {
  int z_height = z_list.rows() / N;
  int x_height = Cx_list.rows() / N;
  int x_width = Cx_list.cols();
  int y_width = Cy_list.cols();
  int z_width = z_list.cols();
  RowMatrixXd temp_xz = RowMatrixXd::Zero(z_height, x_width);
  RowMatrixXd temp_zy = RowMatrixXd::Zero(z_height, y_width);

  RowMatrixXd zx;
  //#pragma omp parallel for reduction(+:temp_xz, temp_zy)
  for (int i = 0; i < N; ++i) {
    Ref<RowMatrixXd> z = z_list.block(z_height * i, 0, z_height, z_width);

    Ref<RowMatrixXd> x = Cx_list.block(x_height * i, 0, x_height, x_width);

    Ref<RowMatrixXd> y = Cy_list.block(x_height * i, 0, x_height, y_width);

    temp_xz.noalias() += z * x;   //  .transpose();
    if(i==0)
     cout <<(z)<<endl;
    temp_zy.noalias() += (z * y); //.transpose();
  }
  

  RowMatrixXd tbr_xz;
  RowMatrixXd diag_dep = RowMatrixXd::Identity(y_width, y_width);
  tbr_xz = Eigen::kroneckerProduct(temp_xz, diag_dep);

  Map<RowMatrixXd> tbr_zy(temp_zy.data(), temp_zy.cols() * temp_zy.rows(), 1);
  
  return std::make_tuple(tbr_xz.transpose(), tbr_zy.transpose());
}

RowMatrixXd calculate_W(Ref<RowMatrixXd> H, Ref<RowMatrixXd> z_list,
                        Ref<MatrixXd> _z_t_list, int step, int N) {
  int z_height = z_list.rows() / N;
  int z_width = z_list.cols();

  RowMatrixXd temp_W = RowMatrixXd::Zero(z_height, z_height);

#pragma omp parallel for reduction(+ : temp_W)
  for (int i = 0; i < N; ++i) {
    Ref<RowMatrixXd> z = z_list.block(z_height * i, 0, z_height, z_width);
  
    temp_W += z * H * z.transpose();
  }
  
  return temp_W;
}

RowMatrixXd calculate_residual(Ref<RowMatrixXd> y_list, Ref<RowMatrixXd> x_list,
                               Ref<RowMatrixXd> beta) {

  
  RowMatrixXd tbr = y_list - x_list * beta;
  saveData("residual.csv", tbr);
  return tbr;
}

RowMatrixXd vcov_step_1(Ref<RowMatrixXd> _M_XZ_W, Ref<RowMatrixXd> W2, int N) {
  // Ref<RowMatrixXd> W2 = step_1.W_next;
  RowMatrixXd tbr = N * (_M_XZ_W * W2 * _M_XZ_W.transpose());
  return tbr;
}

RowMatrixXd vcov(Ref<RowMatrixXd> z_list, Ref<RowMatrixXd> Cx,
                 Ref<RowMatrixXd> M2, Ref<RowMatrixXd> _M2_XZ_W2,
                 Ref<RowMatrixXd> _W2_inv, Ref<RowMatrixXd> zs2, int step,
                 int N) {
  RowMatrixXd tbr;

  Step_Result previous_step = results[step - 2];
  Ref<RowMatrixXd> vcov_step_previous = previous_step.vcov;
  Ref<RowMatrixXd> residual1 = previous_step.residual;

  tbr = Windmeijer(M2, _M2_XZ_W2, _W2_inv, zs2, vcov_step_previous, Cx, z_list,
                   residual1, N);

  return tbr;
}

Hansen_test_info perform_hansen_test(int step, int num_instru, int num_indep,
                                     int num_dep, int N) {
  Step_Result step1 = results[0];
  Step_Result step2 = results[1];
  Step_Result current_step = step2; // to be changed
  //	if (step <= 2)
  //		current_step = step2;
  //	else
  //		current_step = results[step - 1];

  Ref<RowMatrixXd> W2_inv = current_step.W_inv;
  Ref<RowMatrixXd> zs = current_step.zs;

  Hansen_test_info hansen =
      hansen_overid(W2_inv, zs, num_instru * num_dep, num_indep * num_dep, N);
  return hansen;
}

// vector<AR_test_info>
// perform_AR_test(std::unordered_map<string, RowMatrixXd>& final_xy_tables,
// 	Ref<RowMatrixXd> z_list, Ref<RowMatrixXd> _zs_list, int step,
// 	int diff_width, int N, string transformation, bool level) {
// 	Step_Result step2 = results[1];
// 	Step_Result current_step = step2; // to be changed
// 	if (step <= 2)
// 		current_step = step2;
// 	else
// 		current_step = results[step - 1];
// 	int m = 2;
// 	// Eigen::Ref<RowMatrixXd> Cy=final_xy_tables["Cy"];
// 	// Eigen::Ref<RowMatrixXd> Cx=final_xy_tables["Cx"];
// 	// Eigen::Ref<RowMatrixXd> Diff_y = Cy;
// 	// Eigen::Ref<RowMatrixXd> Diff_x = Cx;

// 	vector<AR_test_info> ar_list =
// 		AR_test(N, m, final_xy_tables, z_list, _zs_list,
// current_step.residual, 			current_step._M_XZ_W, current_step.vcov,
// current_step.beta, 			diff_width, transformation, level);

// 	return ar_list;
// }

RowMatrixXd get_H1(Ref<RowMatrixXd> z_list, int diff_width, int T,
                   string transformation, bool level) {
  int width = z_list.cols();
  RowMatrixXd tbr;
  if (transformation == "fd") {
    tbr = RowMatrixXd::Zero(width, width);
    for (int i = 0; i < diff_width; ++i) {
      tbr(i, i) = 2;
      if (i >= 1)
        tbr(i - 1, i) = -1;
      if (i < diff_width - 1)
        tbr(i + 1, i) = -1;
    }
    if (width > diff_width) {
      for (int i = diff_width; i < width; ++i)
        tbr(i, i) = 1;
      Eigen::Ref<RowMatrixXd> low_left =
          tbr.block(diff_width, 0, width - diff_width, diff_width);
      for (int i = 0; i < diff_width; ++i) {
        low_left(i, i) = -1;
        low_left(i + 1, i) = 1;
      }
      Eigen::Ref<RowMatrixXd> up_right =
          tbr.block(0, diff_width, diff_width, width - diff_width);
      for (int i = 0; i < diff_width; ++i) {
        up_right(i, i) = -1;
        up_right(i, i + 1) = 1;
      }
    }
  } else {
    tbr = get_H1_fod(width, diff_width, T, level);
  }
  return tbr;
}

RowMatrixXd get_H1_fod(int width, int diff_width, int T, bool level) {
  RowMatrixXd D_up = generate_D_matrix(diff_width, T);
  if (level) {
    RowMatrixXd D = RowMatrixXd::Zero(width, T);
    D.block(0, 0, diff_width, T) = D_up;
    Eigen::Ref<RowMatrixXd> low_right =
        D.block(diff_width, T - (width - diff_width), width - diff_width,
                width - diff_width);
    for (int i = 0; i < width - diff_width; ++i) {
      low_right(i, i) = 1.0;
    }
    //cout<<D<<endl;
    return D * D.transpose();
  } else {
    return D_up * D_up.transpose();
  }
}

RowMatrixXd generate_D_matrix(int height, int T) {
  //	cout<<height<<endl;
	RowMatrixXd temp=RowMatrixXd::Zero(T, T);
	RowMatrixXd D=RowMatrixXd::Zero(height, T);
	int start;

  for (int i = 0; i < T; ++i) {
    for (int j = i; j < T; ++j) {
      if (i == j)
        temp(i, j) = sqrt((T - i - 1) * 1.0 / (T - i));
      else
        temp(i, j) = (-1) * sqrt(1.0 / ((T - i) * 1.0 * (T - i - 1)));
    }
  }


	  start=num_dep_lags-1;
	//cout<<temp<<endl;
	D=temp.block(start, 0, height, T);
  return D;
}

RowMatrixXd Windmeijer(Ref<RowMatrixXd> M2, Ref<RowMatrixXd> _M2_XZ_W2,
                       Ref<RowMatrixXd> W2_inv, Ref<RowMatrixXd> zs2,
                       Ref<RowMatrixXd> vcov_step1, Ref<RowMatrixXd> Cx_list,
                       Ref<RowMatrixXd> z_list, Ref<RowMatrixXd> residual1,
                       int N) {

  int x_height = Cx_list.rows() / N;
  int z_height = z_list.rows() / N;
  int x_width = Cx_list.cols();
  // int zs_height= zs2.rows();
  int y_width = residual1.cols();

  RowMatrixXd diag_dep = RowMatrixXd::Identity(y_width, y_width);
  RowMatrixXd D = RowMatrixXd::Zero(z_height * y_width * y_width * x_width,
                                    z_height * y_width);
  int z_width = z_list.cols();

  RowMatrixXd zx;
  
  for (int i = 0; i < N; ++i) {
    Ref<RowMatrixXd> x = Cx_list.middleRows(i * x_height, x_height);
    Ref<RowMatrixXd> z = z_list.block(i * z_height, 0, z_height, z_width);

    Ref<RowMatrixXd> u = residual1.middleRows(i * x_height, x_height);

    RowMatrixXd xu; // = x * u_t;
    
    RowMatrixXd temp_xz = z * x;
    zx = Eigen::kroneckerProduct(
        temp_xz, diag_dep); // Eigen::kroneckerProduct(z*x, diag_dep);

    

    RowMatrixXd temp_uz = z * u;
    
    Map<RowMatrixXd> u_z(temp_uz.data(), 1, zx.rows());

    for (int j = 0; j < zx.cols(); ++j) {
    
      Ref<RowMatrixXd> D_j = D.middleRows(j * zx.rows(), zx.rows());

      D_j.noalias() += zx.col(j) * u_z + (zx.col(j) * u_z).transpose();
    }
  }
  
  D = (-1.0 / N) * D;

  RowMatrixXd D_W = RowMatrixXd::Zero(M2.rows(), M2.cols());
  Map<RowMatrixXd> zs_vec(zs2.data(), zs2.rows() * zs2.cols(), 1);

  
  for (int k = 0; k < D_W.cols(); ++k) {

    Ref<RowMatrixXd> partial_dir = D.middleRows(k * zx.rows(), zx.rows());

    RowMatrixXd tt = _M2_XZ_W2 * partial_dir * W2_inv * zs_vec;
  
    D_W.col(k) = (-1) * _M2_XZ_W2 * partial_dir * W2_inv * zs_vec;
  
  }

  
  RowMatrixXd temp = N * M2 + D_W * N * M2 + N * M2 * D_W.transpose();
  temp += D_W * vcov_step1 * D_W.transpose();
  
  return temp;
}
