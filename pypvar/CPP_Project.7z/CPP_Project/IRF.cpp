//
// Created by Tiger on 7/11/2022.
//

#include "IRF.h"


RowMatrixXd PAR1_matrix(RowMatrixXd &beta, int lags) {
  // cols(): num of dep     rows(): num of indep

	int num_dep = beta.cols();
	int num_indep = num_dep * lags;

	//cout << num_indep << " " << num_dep << endl;

  RowMatrixXd tbp = RowMatrixXd::Zero(num_indep, num_indep);

  if (lags == 1) {
    tbp.block(0, 0, num_indep, num_dep) = beta.block(0, 0, num_indep, num_dep);

  } else {
    tbp.block(0, 0, num_indep, num_dep) = beta.block(0, 0, num_indep, num_dep);
    for (int i = 0; i < num_indep - num_dep; ++i) {
      tbp(i, i + num_dep) = 1;
    }
  }

  return (tbp);
}

vector<RowMatrixXd> IRF_matrix(RowMatrixXd &beta, int ahead, int lags){

	int num_dep = beta.cols();
	int num_indep = num_dep * lags;

	RowMatrixXd iden=RowMatrixXd::Identity(num_indep,num_indep);
	RowMatrixXd par1= PAR1_matrix(beta, lags);
	RowMatrixXd J=RowMatrixXd::Zero(num_dep, num_indep);
	for(int i =0;i<num_dep;++i)
		J(i,i)=1;
	vector<RowMatrixXd> tbr;
	//MatrixPower<RowMatrixXd> Apow(par1);

	tbr.push_back(RowMatrixXd::Identity(num_dep, num_dep));
	RowMatrixXd temp= iden;
	for(int i=1; i<ahead; ++i){
		temp=temp* par1;
		RowMatrixXd new_mat=J *temp* J.transpose();
		tbr.push_back(new_mat);
	}


	return tbr;

}

vector<RowMatrixXd>oirf(RowMatrixXd &residual, VectorXi &is_na, RowMatrixXd &beta, int ahead, int lags){
	vector<RowMatrixXd> ma_phi=IRF_matrix(beta, ahead, lags);
	vector<RowMatrixXd> tbr;
	int num_obs=is_na.size()-is_na.sum();
	RowMatrixXd nona_residual(num_obs, residual.cols());
	int new_row=0;
	for(int i=0;i<residual.rows(); ++i){
		if (is_na(i)==0){

			nona_residual.row(new_row)=residual.row(i);
			new_row+=1;
		}
	}

	RowMatrixXd centered = nona_residual.rowwise() - nona_residual.colwise().mean();
	RowMatrixXd cov = (centered.adjoint() * centered) / double(nona_residual.rows() - 1);

	RowMatrixXd p=cov.llt().matrixU();
	cout << p << endl;

	vector<RowMatrixXd> MA_Phi_P;
	for(int i0=0; i0<ahead; ++i0){
		RowMatrixXd temp_mat=p * ma_phi[i0];
		MA_Phi_P.push_back(temp_mat);

	}

	int num_dep=residual.cols();
	for(int i0=0; i0<num_dep;++i0){
		RowMatrixXd temp_mat(ahead, p.cols());
		for(int i=0;i<ahead;++i)
			temp_mat.row(i)=MA_Phi_P[i].row(i0);

		cout <<temp_mat << endl;
		tbr.push_back(temp_mat);
	}

	return (tbr);
}