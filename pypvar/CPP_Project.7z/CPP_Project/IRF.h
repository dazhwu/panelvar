#pragma once
#include <Eigen/MatrixFunctions>
#include "pvar.h"



RowMatrixXd PAR1_matrix(RowMatrixXd &beta, int lags);
vector<RowMatrixXd> IRF_matrix(RowMatrixXd &par1, int ahead, int num_dep);
vector<RowMatrixXd>oirf(RowMatrixXd &, VectorXi &, RowMatrixXd &beta, int ahead, int lags);


