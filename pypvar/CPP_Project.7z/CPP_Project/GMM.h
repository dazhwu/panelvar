//
// Created by Tiger on 5/3/2022.
//

#ifndef UNTITLED_GMM_H
#define UNTITLED_GMM_H

#define EIGEN_INITIALIZE_MATRICES_BY_ZERO
#include <unordered_map>
#include "pvar.h"
#include "info.h"

#include "Step_Result.h"
#include "Common_Functions.h"
#include "Specification_Test.h"
#include <Eigen/KroneckerProduct>


class returned_result{
public:
    struct Regression regression_result;
    Hansen_test_info hansen;
    //vector<AR_test_info> AR_list;
    VectorXcd stability;
    vector<regular_variable> dep_indep;
    struct basic_info model_info;
    struct model_options model_options;
    string command_str;
    returned_result(struct Regression &, Hansen_test_info &, VectorXcd &, struct basic_info &, struct model_options &,string);

};

// std::tuple<vector<Step_Result> , Hansen_test_info , vector<AR_test_info> >
returned_result regular_process(Eigen::Ref<RowMatrixXd>,
                std::unordered_map<string, RowMatrixXd> &, struct basic_info &,
                struct model_options &);



void iterative_GMM(int N, int T, int num_obs, int diff_width, Ref<RowMatrixXd> z_list,
         Ref<MatrixXd> z_list_t, Ref<RowMatrixXd> Cx_list,
         Ref<RowMatrixXd> Cy_list, Ref<RowMatrixXd> _XZ, Ref<RowMatrixXd> _XZ_t,
         Ref<RowMatrixXd> _Zy, Ref<RowMatrixXd> _Zy_t, 
         string transformation, bool level);
         
void GMM(int, int, int, int, Ref <RowMatrixXd>,
         Ref <MatrixXd>,
         Ref <RowMatrixXd>,
         Ref <RowMatrixXd>, Ref <RowMatrixXd>,
         Ref <RowMatrixXd>, Ref <RowMatrixXd>,
         Ref <RowMatrixXd>, int step, string transformation, bool level);

std::tuple<RowMatrixXd, RowMatrixXd, RowMatrixXd, RowMatrixXd>
calculate_ZuuZ(int N, Ref<RowMatrixXd> z_list, RowMatrixXd &residual, RowMatrixXd &,
               int y_width); 
std::tuple <RowMatrixXd, RowMatrixXd> calculate_basic(Ref <RowMatrixXd> z_list,
                                                      Ref <RowMatrixXd> Cx_list,
                                                      Ref <RowMatrixXd> Cy_list, int N);

RowMatrixXd calculate_W(Ref <RowMatrixXd> H,
                        Ref <RowMatrixXd> z_list,
                        Ref <MatrixXd> _z_t_list, int step,
                        int N);

RowMatrixXd calculate_residual(Ref <RowMatrixXd> y_list,
                               Ref <RowMatrixXd> x_list,
                               Ref <RowMatrixXd> beta);

RowMatrixXd vcov_step_1(Ref <RowMatrixXd> _M_XZ_W, Ref <RowMatrixXd> W2, int N);

RowMatrixXd vcov(Ref <RowMatrixXd> z_list,
                 Ref <RowMatrixXd> Cx, Ref <RowMatrixXd> M2, Ref <RowMatrixXd> _M2_XZ_W2, Ref <RowMatrixXd> _W2_inv,
                 Ref <RowMatrixXd> zs2,
                 int step, int N);

void update_MMSC_LU(struct basic_info &model_info, Hansen_test_info &hansen);
Hansen_test_info perform_hansen_test(int step, int num_instru, int num_indep, int num_dep, int N);

// vector <AR_test_info> perform_AR_test(std::unordered_map<string, RowMatrixXd> &,
//                                       Ref <RowMatrixXd> z_list, Ref <RowMatrixXd> _zs_list,
//                                       int step, int diff_width, int N, string transformation, bool level);

/*
std::tuple<Hansen_test_info, vector<AR_test_info>>  perform_test( Ref<RowMatrixXd> ,  Ref<RowMatrixXd> ,
                     Ref<RowMatrixXd> , Ref<RowMatrixXd> ,
                  int num_instru, int num_indep, int step, int didd_width,	int N, string transformation, bool level);
*/
RowMatrixXd get_H1(Ref <RowMatrixXd> z_list, int diff_width, int T,
                   string transformation, bool level);

RowMatrixXd get_H1_fod(int width, int diff_width, int T, bool level);

RowMatrixXd generate_D_matrix(int height, int T);

RowMatrixXd Windmeijer(Ref <RowMatrixXd> M2, Ref <RowMatrixXd> _M2_XZ_W2,
                       Ref <RowMatrixXd> W2_inv, Ref <RowMatrixXd> zs2,
                       Ref <RowMatrixXd> vcov_step1, Ref <RowMatrixXd> Cx_list,
                       Ref <RowMatrixXd> z_list, Ref <RowMatrixXd> residual1_t, int N);


#endif //UNTITLED_GMM_H